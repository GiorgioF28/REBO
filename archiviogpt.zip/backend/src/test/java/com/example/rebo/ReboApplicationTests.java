package com.example.rebo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReboApplicationTests {

	@Test
	void contextLoads() {
	}

}
